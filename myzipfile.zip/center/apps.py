from django.apps import AppConfig


class CenterConfig(AppConfig):
    name = 'center'
